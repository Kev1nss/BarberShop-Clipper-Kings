function editarCadastro(){
  window.location.replace("editarperfil.html");
}